module Starter.Version exposing (version)


version : String
version =
    "0.0.1"
