module Starter.Model exposing (Model)

import Starter.Flags


type alias Model =
    Starter.Flags.Flags
